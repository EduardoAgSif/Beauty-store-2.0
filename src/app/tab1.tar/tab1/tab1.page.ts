import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: false,
})
export class Tab1Page {
  isSignUpMode = true;

  signInData = {
    email: '',
    password: ''
  };

  signUpData = {
    name: '',
    email: '',
    password: ''
  };

  constructor() {}

  toggleMode(signUpState?: boolean) {
    if (signUpState !== undefined) {
      this.isSignUpMode = signUpState;
    } else {
      this.isSignUpMode = !this.isSignUpMode;
    }
    this.resetForms();
  }

  resetForms() {
    this.signInData = {
      email: '',
      password: ''
    };
    this.signUpData = {
      name: '',
      email: '',
      password: ''
    };
  }

  onSignIn() {
    console.log('Signing in with:', this.signInData);
  }

  onSignUp() {
    console.log('Signing up with:', this.signUpData);
  }
}



